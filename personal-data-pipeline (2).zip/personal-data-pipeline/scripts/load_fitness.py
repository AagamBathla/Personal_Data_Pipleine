import pandas as pd
from sqlalchemy import create_engine

RAW_PATH = "data/raw/fitness.csv"
DB_PATH = "sqlite:///data/pipeline.db"


def load_fitness():
    df = pd.read_csv(RAW_PATH)

    # --- Adjust these to match your export's actual column names ---
    df = df.rename(columns={
        "Date": "date",
        "Steps": "steps",
        "Calories": "calories",
        "ActiveMinutes": "active_minutes"
    })

    df["date"] = pd.to_datetime(df["date"])
    df = df.drop_duplicates(subset="date")

    engine = create_engine(DB_PATH)
    df.to_sql("fitness", engine, if_exists="replace", index=False)
    print(f"Loaded {len(df)} days of fitness data")


if __name__ == "__main__":
    load_fitness()
