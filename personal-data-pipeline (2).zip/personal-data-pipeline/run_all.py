import subprocess

steps = [
    "scripts/load_transactions.py",
    "scripts/load_weather.py",
    "scripts/load_fitness.py",
    "scripts/clean_transactions.py",
    "scripts/categorize.py",
    "scripts/merge_daily.py",
]

for step in steps:
    print(f"\n--- Running {step} ---")
    subprocess.run(["python", step], check=True)

print("\nPipeline complete. Run: streamlit run dashboard/app.py")
