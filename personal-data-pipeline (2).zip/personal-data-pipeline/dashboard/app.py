import os
import calendar
from io import BytesIO

from dotenv import load_dotenv

env_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(env_path, override=True)

import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sqlalchemy import create_engine
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

DB_PATH = "sqlite:///data/pipeline.db"

st.set_page_config(page_title="My Personal Data Dashboard", layout="wide", page_icon="💰")

# ============================================================
# DESIGN TOKENS
# ============================================================
COLOR_BG = "#0E1117"
COLOR_SURFACE = "#1A1F2B"
COLOR_SURFACE_2 = "#222838"
COLOR_BORDER = "#2D3445"
COLOR_TEXT = "#E6E8EC"
COLOR_MUTED = "#8B93A7"
COLOR_GOOD = "#10B981"     # emerald — savings, positive trends
COLOR_WARN = "#F59E0B"     # amber — caution, budgets nearing limit
COLOR_BAD = "#EF4444"      # coral — overspend, anomalies
COLOR_ACCENT = "#6366F1"   # indigo — neutral highlight / brand accent

CHART_PALETTE = [COLOR_ACCENT, COLOR_GOOD, COLOR_WARN, COLOR_BAD,
                  "#06B6D4", "#A78BFA", "#F472B6", "#84CC16"]

# Charts are rendered server-side as static images, so they can't detect the
# browser's light/dark setting. Using a transparent background + neutral
# mid-gray text keeps them legible on both themes.
COLOR_CHART_TEXT = "#6B7280"  # neutral gray, readable on light and dark

plt.rcParams.update({
    "figure.facecolor": "none",
    "axes.facecolor": "none",
    "axes.edgecolor": COLOR_CHART_TEXT,
    "axes.labelcolor": COLOR_CHART_TEXT,
    "text.color": COLOR_CHART_TEXT,
    "xtick.color": COLOR_CHART_TEXT,
    "ytick.color": COLOR_CHART_TEXT,
    "axes.prop_cycle": plt.cycler(color=CHART_PALETTE),
    "legend.facecolor": "none",
    "legend.edgecolor": COLOR_CHART_TEXT,
    "savefig.facecolor": "none",
    "savefig.transparent": True,
})

st.markdown(
    f"""
    <style>
    /* ---- Theme-aware tokens: dark by default, overridden in light mode ---- */
    :root {{
        --surface: {COLOR_SURFACE};
        --surface-2: {COLOR_SURFACE_2};
        --border: {COLOR_BORDER};
        --text: {COLOR_TEXT};
        --muted: {COLOR_MUTED};
    }}
    @media (prefers-color-scheme: light) {{
        :root {{
            --surface: #FFFFFF;
            --surface-2: #F3F5F9;
            --border: #E2E5EC;
            --text: #1A1F2B;
            --muted: #5B6478;
        }}
    }}

    /* ---- Card-style metric helper (used via render_metric_card) ---- */
    .metric-card {{
        background: var(--surface);
        border: 1px solid var(--border);
        border-left: 4px solid var(--accent, {COLOR_ACCENT});
        border-radius: 10px;
        padding: 14px 18px;
        margin-bottom: 8px;
    }}
    .metric-card .label {{
        font-size: 0.78rem;
        color: var(--muted);
        text-transform: uppercase;
        letter-spacing: 0.04em;
        margin-bottom: 4px;
    }}
    .metric-card .value {{
        font-size: 1.6rem;
        font-weight: 700;
        color: var(--text);
        line-height: 1.2;
        font-variant-numeric: tabular-nums;
    }}
    .metric-card .sub {{
        font-size: 0.8rem;
        color: var(--muted);
        margin-top: 2px;
    }}

    /* ---- Section headers ---- */
    .section-header {{
        font-size: 1.05rem;
        font-weight: 700;
        color: var(--text);
        border-bottom: 1px solid var(--border);
        padding-bottom: 6px;
        margin: 18px 0 12px 0;
    }}

    /* ---- Hero banner ---- */
    .hero-banner {{
        background: linear-gradient(135deg, var(--surface-2) 0%, var(--surface) 100%);
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 22px 26px;
        margin-bottom: 18px;
    }}
    .hero-title {{
        font-size: 1.5rem;
        font-weight: 800;
        color: var(--text);
        margin-bottom: 2px;
    }}
    .hero-subtitle {{
        font-size: 0.9rem;
        color: var(--muted);
    }}

    /* ---- Tabs ---- */
    .stTabs [data-baseweb="tab-list"] {{
        gap: 4px;
    }}
    .stTabs [data-baseweb="tab"] {{
        background-color: var(--surface);
        border-radius: 8px 8px 0 0;
        padding: 8px 16px;
        color: var(--muted);
    }}
    .stTabs [aria-selected="true"] {{
        background-color: var(--surface-2);
        color: var(--text) !important;
        border-bottom: 2px solid {COLOR_ACCENT};
    }}

    /* ---- Dataframes / tables ---- */
    div[data-testid="stDataFrame"] {{
        border: 1px solid var(--border);
        border-radius: 8px;
        overflow: hidden;
    }}
    </style>
    """,
    unsafe_allow_html=True,
)


def render_metric_card(label, value, sub=None, accent=COLOR_ACCENT):
    """Render a single card-style metric with a colored left accent bar."""
    sub_html = f'<div class="sub">{sub}</div>' if sub else ""
    st.markdown(
        f"""
        <div class="metric-card" style="--accent:{accent}">
            <div class="label">{label}</div>
            <div class="value">{value}</div>
            {sub_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def section_header(text):
    st.markdown(f'<div class="section-header">{text}</div>', unsafe_allow_html=True)

# ============================================================
# LOAD DATA
# ============================================================
engine = create_engine(DB_PATH)
df = pd.read_sql("categorized_transactions", engine)
df["date"] = pd.to_datetime(df["date"])

expenses_all = df[df["amount"] < 0].copy()
expenses_all["amount"] = expenses_all["amount"].abs()
income_all = df[df["amount"] > 0].copy()

# ============================================================
# SIDEBAR: FILTERS
# ============================================================
st.sidebar.header("🔍 Filters")

min_date = expenses_all["date"].min().date()
max_date = expenses_all["date"].max().date()

date_range = st.sidebar.date_input(
    "Date range",
    value=(min_date, max_date),
    min_value=min_date,
    max_value=max_date,
)

if isinstance(date_range, tuple) and len(date_range) == 2:
    start_date, end_date = date_range
else:
    start_date, end_date = min_date, max_date

all_categories = sorted(expenses_all["category"].unique())
selected_categories = st.sidebar.multiselect(
    "Categories",
    options=all_categories,
    default=all_categories,
)

mask = (
    (expenses_all["date"].dt.date >= start_date)
    & (expenses_all["date"].dt.date <= end_date)
    & (expenses_all["category"].isin(selected_categories))
)
expenses = expenses_all[mask].copy()

# ============================================================
# SIDEBAR: BUDGETS
# ============================================================
st.sidebar.header("💸 Monthly Budgets")
st.sidebar.caption("Set a budget per category to track against total spend")

budgets = {}
for cat in all_categories:
    if cat == "income":
        continue
    default_budget = int(expenses_all[expenses_all["category"] == cat]["amount"].sum())
    budgets[cat] = st.sidebar.number_input(
        f"{cat.title()} budget (₹)",
        min_value=0,
        value=max(default_budget, 0),
        step=100,
    )

# ============================================================
# SIDEBAR: SAVINGS GOAL
# ============================================================
st.sidebar.header("🎯 Savings Goal")
goal_amount = st.sidebar.number_input("Goal Amount (₹)", value=100000, step=1000)

# ============================================================
# SHARED CALCULATIONS (used across multiple tabs)
# ============================================================
total_income = income_all["amount"].sum()
total_expense = expenses_all["amount"].sum()
savings = total_income - total_expense
savings_rate = (savings / total_income * 100) if total_income > 0 else 0

by_category_all = expenses_all.groupby("category")["amount"].sum().sort_values(ascending=False)

latest_date = expenses_all["date"].max()
this_week = expenses_all[expenses_all["date"] > latest_date - pd.Timedelta(days=7)]
last_week = expenses_all[
    (expenses_all["date"] <= latest_date - pd.Timedelta(days=7))
    & (expenses_all["date"] > latest_date - pd.Timedelta(days=14))
]
this_week_total = this_week["amount"].sum()
last_week_total = last_week["amount"].sum()

# Anomalies
stats = expenses_all.groupby("category")["amount"].agg(["mean", "std"]).fillna(0)
stats = stats.rename(columns={"mean": "cat_mean", "std": "cat_std"})
flagged = expenses_all.merge(stats, on="category")
flagged["threshold"] = flagged["cat_mean"] + 2 * flagged["cat_std"]
anomalies = flagged[(flagged["amount"] > flagged["threshold"]) & (flagged["cat_std"] > 0)]

# Top merchants + recurring subscriptions
top_merchants = (
    expenses_all.groupby("description")["amount"]
    .agg(total_spent="sum", times="count")
    .sort_values("total_spent", ascending=False)
    .head(8)
)
merchant_stats = (
    expenses_all.groupby("description")["amount"]
    .agg(times_seen="count", amount_each="mean", amount_std="std")
    .fillna(0)
)
recurring = merchant_stats[
    (merchant_stats["times_seen"] >= 2)
    & (merchant_stats["amount_std"] < merchant_stats["amount_each"] * 0.1)
].sort_values("amount_each", ascending=False)

# Monthly trend + forecast
monthly = expenses_all.copy()
monthly["month"] = monthly["date"].dt.to_period("M").astype(str)
monthly_totals = monthly.groupby("month")["amount"].sum()

current_period = latest_date.to_period("M")
current_month_data = expenses_all[expenses_all["date"].dt.to_period("M") == current_period]
days_elapsed = (latest_date - current_period.start_time).days + 1
days_in_month = calendar.monthrange(current_period.year, current_period.month)[1]
spend_so_far = current_month_data["amount"].sum()
daily_avg = spend_so_far / days_elapsed if days_elapsed > 0 else 0
forecast = daily_avg * days_in_month

# Category trends (month over month)
monthly_category = (
    expenses_all.groupby([expenses_all["date"].dt.to_period("M"), "category"])["amount"]
    .sum()
    .unstack(fill_value=0)
)
monthly_category.index = monthly_category.index.astype(str)

# Financial health score
score = 100
if savings_rate < 20:
    score -= 20
if len(anomalies) > 5:
    score -= 10

overspent_categories = 0
for cat in selected_categories:
    if cat == "income":
        continue
    spent = expenses[expenses["category"] == cat]["amount"].sum()
    budget = budgets.get(cat, 0)
    if budget > 0 and spent > budget:
        overspent_categories += 1
score -= overspent_categories * 5
score = max(0, min(score, 100))

if score >= 80:
    health_status = "Excellent 🟢"
elif score >= 60:
    health_status = "Good 🟡"
else:
    health_status = "Needs Improvement 🔴"


# ============================================================
# HELPER FUNCTIONS
# ============================================================
def build_summary():
    recurring_dict = recurring["amount_each"].round(0).to_dict() if len(recurring) else {}
    return (
        f"Total income: ₹{total_income:,.0f}\n"
        f"Total expenses: ₹{total_expense:,.0f}\n"
        f"Savings rate: {savings_rate:.1f}%\n"
        f"Spend by category: {by_category_all.round(0).to_dict()}\n"
        f"Top merchants: {top_merchants['total_spent'].round(0).to_dict()}\n"
        f"Recurring subscriptions: {recurring_dict}\n"
        f"Projected month-end total: ₹{forecast:,.0f}"
    )


def get_recent_transactions():
    return expenses_all.sort_values("date", ascending=False).head(100)


def get_ai_insights(summary_text: str) -> str:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return (
            "⚠️ OPENAI_API_KEY environment variable is not set. "
            "Get an API key from console.openai.com, set it, then try again."
        )
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            max_tokens=600,
            messages=[{
                "role": "user",
                "content": (
                    "Here is a summary of my personal spending data:\n\n"
                    f"{summary_text}\n\n"
                    "Analyze this data and give me 3-5 short, actionable "
                    "insights/suggestions in English (as bullet points). "
                    "Use specific numbers from the summary above."
                ),
            }],
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"⚠️ Error generating AI insights: {e}"


def ask_ai_about_data(summary_text, question):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return "⚠️ OPENAI_API_KEY is not set."
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        recent_transactions = get_recent_transactions()
        prompt = f"""
Financial Summary:
{summary_text}

Recent Transactions:
{recent_transactions[['date', 'description', 'category', 'amount']].to_string(index=False)}

Question:
{question}

Answer using actual transaction data.
Use numbers wherever possible.
Keep response concise.
"""
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300,
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"⚠️ Error: {e}"


def generate_smart_budget():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return "⚠️ OPENAI_API_KEY is not set."
    budget_prompt = f"""
You are a personal finance advisor.

Financial Summary:
{build_summary()}

Current Category Spending:
{by_category_all.to_dict()}

Monthly Income:
₹{total_income:,.0f}

Create an optimized monthly budget.

Return in markdown table format:
| Category | Recommended Budget | Reason |

Rules:
- Ensure savings are at least 20% of income.
- Reduce overspending categories.
- Keep recommendations practical.
- Use ₹ currency.
- Keep response concise.
"""
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[{"role": "user", "content": budget_prompt}],
            max_tokens=600,
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"⚠️ Error generating budget: {e}"


def generate_pdf_report(summary_text, ai_insights):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer)
    styles = getSampleStyleSheet()
    content = [
        Paragraph("Personal Finance Report", styles["Title"]),
        Spacer(1, 12),
        Paragraph(summary_text.replace("\n", "<br/>"), styles["BodyText"]),
        Spacer(1, 12),
        Paragraph("AI Insights", styles["Heading2"]),
        Paragraph(ai_insights.replace("\n", "<br/>"), styles["BodyText"]),
    ]
    doc.build(content)
    buffer.seek(0)
    return buffer


# ============================================================
# SESSION STATE INIT
# ============================================================
for key, default in [
    ("latest_ai_insights", ""),
    ("summary_text", ""),
    ("smart_budget", ""),
    ("messages", []),
    ("quick_prompt", None),
]:
    if key not in st.session_state:
        st.session_state[key] = default


# ============================================================
# HERO BANNER
# ============================================================
_hero_accent = COLOR_GOOD if savings_rate >= 20 else (COLOR_WARN if savings_rate >= 0 else COLOR_BAD)
st.markdown(
    f"""
    <div class="hero-banner">
        <div class="hero-title">💰 My Personal Data Dashboard</div>
        <div class="hero-subtitle">
            {start_date.strftime('%d %b')} – {end_date.strftime('%d %b %Y')} &nbsp;•&nbsp;
            Savings rate <span style="color:{_hero_accent}; font-weight:700;">{savings_rate:.1f}%</span> &nbsp;•&nbsp;
            Health score <span style="color:{_hero_accent}; font-weight:700;">{score}/100</span>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

# ============================================================
# TABS
# ============================================================
tab_dashboard, tab_finance, tab_reports, tab_ai = st.tabs([
    "📊 Dashboard",
    "💰 Finance",
    "📄 Reports",
    "🤖 Finance Copilot",
])

# ============================================================
# TAB 1: DASHBOARD
# ============================================================
with tab_dashboard:
    section_header("💰 Spending Overview")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        render_metric_card("Total Spend", f"₹{expenses['amount'].sum():,.0f}", accent=COLOR_ACCENT)
    with col2:
        avg_txn = f"₹{expenses['amount'].mean():,.0f}" if len(expenses) else "₹0"
        render_metric_card("Avg Transaction", avg_txn, accent=COLOR_ACCENT)
    with col3:
        render_metric_card("Transactions", str(len(expenses)), accent=COLOR_ACCENT)
    with col4:
        render_metric_card("Days Covered", f"{(end_date - start_date).days + 1}", accent=COLOR_ACCENT)

    section_header("📰 Quick Digest")
    if last_week_total > 0:
        change_pct = ((this_week_total - last_week_total) / last_week_total) * 100
        trend = "higher" if change_pct > 0 else "lower"
        digest_trend = f"That's **{abs(change_pct):.0f}% {trend}** than last week."
    else:
        digest_trend = "No data available for last week to compare."

    if len(this_week):
        top_cat = this_week.groupby("category")["amount"].sum().idxmax()
        top_cat_amount = this_week.groupby("category")["amount"].sum().max()
        biggest_txn = this_week.loc[this_week["amount"].idxmax()]
        st.info(
            f"**Last 7 days:** Total spend ₹{this_week_total:,.0f}. "
            f"{digest_trend}\n\n"
            f"Highest spend was in: **{top_cat}** (₹{top_cat_amount:,.0f}).\n\n"
            f"Biggest single transaction: **{biggest_txn['description'].title()}** "
            f"— ₹{biggest_txn['amount']:,.0f} on {biggest_txn['date'].date()}."
        )
    else:
        st.info("No transactions found in the last 7 days.")

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Spend by category")
        by_category = expenses.groupby("category")["amount"].sum().sort_values(ascending=False)
        if len(by_category):
            fig, ax = plt.subplots()
            fig.patch.set_alpha(0.0)
            ax.pie(by_category, labels=by_category.index, autopct="%1.1f%%", startangle=90)
            ax.axis("equal")
            st.pyplot(fig, transparent=True)
        else:
            st.write("No data for selected filters")

    with c2:
        st.subheader("Weekday vs Weekend")
        by_weekend = expenses.groupby("is_weekend")["amount"].sum()
        by_weekend.index = by_weekend.index.map({True: "Weekend", False: "Weekday"})
        st.bar_chart(by_weekend)

    st.subheader("Daily spend over time")
    if len(expenses):
        daily = expenses.groupby(expenses["date"].dt.date)["amount"].sum()
        st.line_chart(daily)
    else:
        st.write("No data for selected filters")

    st.subheader("📈 Category Trends (by month)")
    st.line_chart(monthly_category)

    if len(monthly_category) >= 2:
        latest_m = monthly_category.iloc[-1]
        previous_m = monthly_category.iloc[-2]
        trend_df = pd.DataFrame({"Current": latest_m, "Previous": previous_m})
        trend_df["Change %"] = (
            (trend_df["Current"] - trend_df["Previous"])
            / trend_df["Previous"].replace(0, 1)
            * 100
        ).round(1)
        st.caption("Month-over-Month Change")
        st.dataframe(trend_df.sort_values("Change %", ascending=False))

    section_header("🚨 AI Spending Alerts")
    st.caption("Automatic alerts based on spending patterns, budgets, and savings.")

    alerts = []

    if len(monthly_category) >= 2:
        current_month = monthly_category.iloc[-1]
        previous_month = monthly_category.iloc[-2]
        for category in monthly_category.columns:
            current = current_month.get(category, 0)
            previous = previous_month.get(category, 0)
            if previous > 0:
                change_pct = (current - previous) / previous * 100
                if change_pct > 20:
                    alerts.append(f"⚠️ {category.title()} spending increased by {change_pct:.0f}% compared to last month.")
                elif change_pct < -20:
                    alerts.append(f"✅ {category.title()} spending decreased by {abs(change_pct):.0f}% compared to last month.")

    for cat in selected_categories:
        if cat == "income":
            continue
        spent = expenses[expenses["category"] == cat]["amount"].sum()
        budget = budgets.get(cat, 0)
        if budget > 0 and spent > budget:
            alerts.append(f"🚨 {cat.title()} exceeded budget by ₹{spent - budget:,.0f}")

    if savings_rate < 10:
        alerts.append(f"🚨 Savings rate is only {savings_rate:.1f}% — immediate attention recommended.")
    elif savings_rate < 20:
        alerts.append(f"⚠️ Savings rate is {savings_rate:.1f}% (recommended: 20%+)")
    elif savings_rate >= 30:
        alerts.append(f"🎉 Excellent savings rate of {savings_rate:.1f}%!")

    if len(recurring):
        recurring_total = recurring["amount_each"].sum()
        alerts.append(f"🔄 Estimated recurring subscription spend: ₹{recurring_total:,.0f}/month")

    if len(by_category_all):
        top_category_name = by_category_all.idxmax()
        top_category_amount = by_category_all.max()
        alerts.append(f"💸 Highest spending category: {top_category_name.title()} (₹{top_category_amount:,.0f})")

    if alerts:
        for alert in alerts:
            if "🚨" in alert:
                st.error(alert)
            elif "⚠️" in alert:
                st.warning(alert)
            elif "✅" in alert or "🎉" in alert:
                st.success(alert)
            else:
                st.info(alert)
    else:
        st.success("No major financial alerts detected.")

# ============================================================
# TAB 2: FINANCE
# ============================================================
with tab_finance:
    section_header("🎯 Budget Tracker")
    st.caption("Based on total spend in the selected date range, per category")

    for cat in selected_categories:
        if cat == "income":
            continue
        spent = expenses[expenses["category"] == cat]["amount"].sum()
        budget = budgets.get(cat, 0)
        if budget > 0:
            pct = min(spent / budget, 1.0)
            st.write(f"**{cat.title()}**: ₹{spent:,.0f} / ₹{budget:,.0f}")
            st.progress(pct)
            if spent > budget:
                st.warning(f"{cat.title()} is over budget by ₹{spent - budget:,.0f}!")
        else:
            st.write(f"**{cat.title()}**: ₹{spent:,.0f} (no budget set)")

    section_header("🚨 Unusual Transactions")
    st.caption("Transactions significantly larger than your typical spend in that category")
    if len(anomalies):
        st.dataframe(
            anomalies[["date", "description", "category", "amount", "cat_mean"]]
            .rename(columns={"cat_mean": "category_avg"})
            .sort_values("date", ascending=False)
        )
    else:
        st.write("Nothing unusual found — all transactions are within normal range.")

    section_header("💵 Income vs Expenses")
    i1, i2, i3 = st.columns(3)
    with i1:
        render_metric_card("Total Income", f"₹{total_income:,.0f}", accent=COLOR_GOOD)
    with i2:
        render_metric_card("Total Expenses", f"₹{total_expense:,.0f}", accent=COLOR_BAD)
    with i3:
        savings_accent = COLOR_GOOD if savings_rate >= 0 else COLOR_BAD
        render_metric_card("Savings", f"₹{savings:,.0f}", f"{savings_rate:.1f}% of income", accent=savings_accent)
    if savings_rate < 0:
        st.warning(f"You're spending more than your income — expenses exceed income by ₹{abs(savings):,.0f}.")

    section_header("🎯 Goal Planner")
    if savings > 0:
        months_needed = goal_amount / savings
        render_metric_card("Months Needed", f"{months_needed:.1f}", f"to reach ₹{goal_amount:,.0f}", accent=COLOR_ACCENT)
        st.success(f"At your current savings rate, it'll take about {months_needed:.1f} months to reach ₹{goal_amount:,.0f}.")
    else:
        st.warning("Your savings are not currently positive.")

    section_header("🏥 Financial Health Score")
    hc1, hc2 = st.columns(2)
    health_accent = COLOR_GOOD if score >= 80 else (COLOR_WARN if score >= 60 else COLOR_BAD)
    with hc1:
        render_metric_card("Financial Health Score", f"{score}/100", accent=health_accent)
    with hc2:
        render_metric_card("Status", health_status, accent=health_accent)
    st.progress(score / 100)

# ============================================================
# TAB 3: REPORTS
# ============================================================
with tab_reports:
    section_header("🏪 Top Merchants & Subscriptions")
    m1, m2 = st.columns(2)

    with m1:
        st.subheader("Top Merchants (overall)")
        st.dataframe(top_merchants)

    with m2:
        st.subheader("Likely Recurring Subscriptions")
        if len(recurring):
            st.dataframe(recurring[["amount_each", "times_seen"]])
            st.write(f"Estimated recurring spend: **₹{recurring['amount_each'].sum():,.0f}/cycle**")
        else:
            st.write(
                "Not enough history yet to detect recurring patterns "
                "(needs at least 2 charges from the same merchant for the same amount)."
            )

    section_header("📈 Monthly Trend & Forecast")
    t1, t2 = st.columns([2, 1])

    with t1:
        st.subheader("Spend by month")
        st.bar_chart(monthly_totals)

    with t2:
        st.subheader("This month's forecast")
        render_metric_card("Spent So Far", f"₹{spend_so_far:,.0f}", f"{days_elapsed}/{days_in_month} days", accent=COLOR_ACCENT)
        render_metric_card("Projected Month-End Total", f"₹{forecast:,.0f}", accent=COLOR_WARN)
        if len(monthly_totals) >= 2:
            prev_month_total = monthly_totals.iloc[-2]
            diff_pct = ((forecast - prev_month_total) / prev_month_total) * 100
            direction = "higher" if diff_pct > 0 else "lower"
            st.caption(f"That's ~{abs(diff_pct):.0f}% {direction} than last month.")

    section_header("🔍 Transactions (filtered)")
    st.dataframe(expenses.sort_values("date", ascending=False))

# ============================================================
# TAB 4: AI / FINANCE COPILOT
# ============================================================
with tab_ai:
    section_header("🤖 AI Insights")
    st.caption("An AI-generated summary and suggestions based on your spending data")

    if st.button("✨ Generate AI Insights"):
        with st.spinner("Analyzing your data..."):
            summary_text = build_summary()
            insights = get_ai_insights(summary_text)
            st.session_state.latest_ai_insights = insights
            st.session_state.summary_text = summary_text
            st.markdown(insights)

    if st.session_state.latest_ai_insights:
        pdf = generate_pdf_report(st.session_state.summary_text, st.session_state.latest_ai_insights)
        st.download_button(
            "📄 Download PDF Report",
            pdf,
            file_name="finance_report.pdf",
            mime="application/pdf",
        )

    st.divider()
    header_col, clear_col = st.columns([5, 1])
    with header_col:
        section_header("💬 Finance Copilot")
    with clear_col:
        if st.button("🗑️ Clear Chat", use_container_width=True, disabled=not st.session_state.messages):
            st.session_state.messages = []
            st.rerun()

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    st.subheader("⚡ Quick Questions")
    qc1, qc2, qc3 = st.columns(3)

    if qc1.button("💸 Biggest Expense"):
        st.session_state.quick_prompt = "What is my biggest expense?"
    if qc2.button("📉 Reduce Spending"):
        st.session_state.quick_prompt = "Which category should I reduce?"
    if qc3.button("🎯 Savings Advice"):
        st.session_state.quick_prompt = "How can I improve my savings?"

    if st.session_state.quick_prompt:
        prompt = st.session_state.quick_prompt
        st.session_state.quick_prompt = None
        summary_text = build_summary()
        answer = ask_ai_about_data(summary_text, prompt)
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.session_state.messages.append({"role": "assistant", "content": answer})
        st.rerun()

    user_prompt = st.chat_input("Ask about your finances...")
    if user_prompt:
        summary_text = build_summary()
        answer = ask_ai_about_data(summary_text, user_prompt)
        st.session_state.messages.append({"role": "user", "content": user_prompt})
        st.session_state.messages.append({"role": "assistant", "content": answer})
        st.rerun()

    st.divider()
    with st.expander("🤖 Smart Budget Generator", expanded=False):
        st.caption("Generate an AI-powered monthly budget based on your spending patterns.")

        bc1, bc2 = st.columns(2)
        with bc1:
            income_input = st.number_input("Monthly Income (₹)", value=int(total_income), step=1000)
        with bc2:
            savings_goal = st.number_input("Desired Savings (₹)", value=10000, step=1000)

        if st.button("🚀 Generate Smart Budget", use_container_width=True):
            with st.spinner("Analyzing your spending patterns..."):
                st.session_state.smart_budget = generate_smart_budget()

        if st.session_state.smart_budget:
            st.markdown(st.session_state.smart_budget)
