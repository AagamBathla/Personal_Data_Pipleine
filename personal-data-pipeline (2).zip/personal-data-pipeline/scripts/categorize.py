import pandas as pd
from sqlalchemy import create_engine

DB_PATH = "sqlite:///data/pipeline.db"

CATEGORY_RULES = {
    "income": ["salary", "credit", "bonus", "refund"],
    "food": ["restaurant", "cafe", "swiggy", "zomato", "starbucks", "mcdonald"],
    "transport": ["uber", "ola", "petrol", "fuel", "metro"],
    "groceries": ["grocer", "supermarket", "bigbasket", "dmart"],
    "shopping": ["amazon", "flipkart", "myntra"],
    "bills": ["electricity", "recharge", "broadband", "insurance"],
    "entertainment": ["netflix", "spotify", "movie", "bookmyshow"],
}


def categorize_row(description):
    for category, keywords in CATEGORY_RULES.items():
        if any(kw in description for kw in keywords):
            return category
    return "uncategorized"


def categorize():
    engine = create_engine(DB_PATH)
    df = pd.read_sql("clean_transactions", engine)

    df["category"] = df["description"].apply(categorize_row)

    df.to_sql("categorized_transactions", engine, if_exists="replace", index=False)

    uncategorized_pct = (df["category"] == "uncategorized").mean() * 100
    print(f"Done. {uncategorized_pct:.1f}% still uncategorized")


if __name__ == "__main__":
    categorize()
