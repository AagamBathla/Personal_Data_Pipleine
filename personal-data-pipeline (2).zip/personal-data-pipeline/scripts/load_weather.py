import requests
import pandas as pd
from sqlalchemy import create_engine

DB_PATH = "sqlite:///data/pipeline.db"

# --- Set your city's coordinates ---
LATITUDE = 30.13   # Yamuna Nagar area, adjust as needed
LONGITUDE = 77.28


def get_date_range(engine):
    """Match weather dates to your transaction date range."""
    df = pd.read_sql("raw_transactions", engine)
    df["date"] = pd.to_datetime(df["date"])
    return df["date"].min().date(), df["date"].max().date()


def load_weather():
    engine = create_engine(DB_PATH)
    start, end = get_date_range(engine)

    url = (
        "https://archive-api.open-meteo.com/v1/archive"
        f"?latitude={LATITUDE}&longitude={LONGITUDE}"
        f"&start_date={start}&end_date={end}"
        "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum"
        "&timezone=auto"
    )

    resp = requests.get(url)
    resp.raise_for_status()
    data = resp.json()["daily"]

    df = pd.DataFrame({
        "date": pd.to_datetime(data["time"]),
        "temp_max": data["temperature_2m_max"],
        "temp_min": data["temperature_2m_min"],
        "precipitation": data["precipitation_sum"],
    })

    df.to_sql("weather", engine, if_exists="replace", index=False)
    print(f"Loaded weather for {len(df)} days")


if __name__ == "__main__":
    load_weather()
