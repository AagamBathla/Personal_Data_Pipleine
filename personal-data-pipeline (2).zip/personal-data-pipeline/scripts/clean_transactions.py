import pandas as pd
from sqlalchemy import create_engine

DB_PATH = "sqlite:///data/pipeline.db"


def clean():
    engine = create_engine(DB_PATH)
    df = pd.read_sql("raw_transactions", engine)

    # Drop exact duplicate rows
    df = df.drop_duplicates()

    # Make sure amount is numeric, drop rows that fail
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    df = df.dropna(subset=["amount"])

    # Standardize description text
    df["description"] = df["description"].str.strip().str.lower()

    # Add useful date fields
    df["date"] = pd.to_datetime(df["date"])
    df["day_of_week"] = df["date"].dt.day_name()
    df["is_weekend"] = df["date"].dt.dayofweek >= 5
    df["month"] = df["date"].dt.to_period("M").astype(str)

    df.to_sql("clean_transactions", engine, if_exists="replace", index=False)
    print(f"Cleaned table has {len(df)} rows")


if __name__ == "__main__":
    clean()
