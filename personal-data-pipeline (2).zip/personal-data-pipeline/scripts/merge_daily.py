import pandas as pd
from sqlalchemy import create_engine

DB_PATH = "sqlite:///data/pipeline.db"


def merge():
    engine = create_engine(DB_PATH)

    tx = pd.read_sql("categorized_transactions", engine)
    weather = pd.read_sql("weather", engine)
    fitness = pd.read_sql("fitness", engine)

    for d in (tx, weather, fitness):
        d["date"] = pd.to_datetime(d["date"]).dt.date

    # Daily spend (only expenses, i.e. negative amounts)
    expenses = tx[tx["amount"] < 0].copy()
    expenses["amount"] = expenses["amount"].abs()
    daily_spend = expenses.groupby("date")["amount"].sum().reset_index()
    daily_spend = daily_spend.rename(columns={"amount": "total_spend"})

    # Merge everything on date (outer join so missing days still show)
    summary = daily_spend.merge(weather, on="date", how="outer")
    summary = summary.merge(fitness, on="date", how="outer")
    summary = summary.sort_values("date").fillna(0)

    summary.to_sql("daily_summary", engine, if_exists="replace", index=False)
    print(f"daily_summary has {len(summary)} rows")


if __name__ == "__main__":
    merge()
