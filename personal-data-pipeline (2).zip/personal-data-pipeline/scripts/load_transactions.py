import pandas as pd
from sqlalchemy import create_engine

RAW_PATH = "data/raw/transactions.csv"
DB_PATH = "sqlite:///data/pipeline.db"


def load():
    df = pd.read_csv(RAW_PATH)

    # --- Adjust these column names to match your bank's export ---
    df = df.rename(columns={
        "Date": "date",
        "Description": "description",
        "Amount": "amount"
    })

    df["date"] = pd.to_datetime(df["date"])

    engine = create_engine(DB_PATH)
    df.to_sql("raw_transactions", engine, if_exists="replace", index=False)
    print(f"Loaded {len(df)} rows into raw_transactions")


if __name__ == "__main__":
    load()
